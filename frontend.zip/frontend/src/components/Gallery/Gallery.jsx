import cls from './Gallery.module.scss';

export const Gallery = () => {
  return (
    <section className={cls.section} />
  );
};
